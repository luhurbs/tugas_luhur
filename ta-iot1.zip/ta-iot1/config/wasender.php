<?php

return [
    "token" => "VzgNHEAxNckrePCkVsP!",
    "endpoint" => "https://api.fonnte.com"
];
