 <!-- jQuery first, then Popper.js, then Bootstrap JS -->
 <script src="js/jquery.min.js"></script>
 <script src="js/popper.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <!-- Appear JavaScript -->
 <script src="js/jquery.appear.js"></script>
 <!-- Countdown JavaScript -->
 <script src="js/countdown.min.js"></script>
 <!-- Counterup JavaScript -->
 <script src="js/waypoints.min.js"></script>
 <script src="js/jquery.counterup.min.js"></script>
 <!-- Wow JavaScript -->
 <script src="js/wow.min.js"></script>
 <!-- Apexcharts JavaScript -->
 <script src="js/apexcharts.js"></script>
 <!-- Slick JavaScript -->
 <script src="js/slick.min.js"></script>
 <!-- Select2 JavaScript -->
 <script src="js/select2.min.js"></script>
 <!-- Owl Carousel JavaScript -->
 <script src="js/owl.carousel.min.js"></script>
 <!-- Magnific Popup JavaScript -->
 <script src="js/jquery.magnific-popup.min.js"></script>
 <!-- Smooth Scrollbar JavaScript -->
 <script src="js/smooth-scrollbar.js"></script>
 <!-- lottie JavaScript -->
 <script src="js/lottie.js"></script>
 <!-- Chart Custom JavaScript -->
 <script src="js/chart-custom.js"></script>
 <!-- Custom JavaScript -->
 <script src="js/custom.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
