@extends('layouts.dashboard')

@section('content')
    luhurbs
@endsection
