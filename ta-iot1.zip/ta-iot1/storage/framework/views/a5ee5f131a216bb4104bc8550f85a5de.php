
<?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1(1)\ta-iot1\resources\views/layouts/dashboard/loader.blade.php ENDPATH**/ ?>