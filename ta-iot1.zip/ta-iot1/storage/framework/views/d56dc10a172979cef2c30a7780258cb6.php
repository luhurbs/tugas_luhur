<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.dashboard._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- loader Start -->
    <?php echo $__env->make('layouts.dashboard.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- loader END -->

    <!-- Wrapper Start -->
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php echo $__env->make('layouts.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- TOP Nav Bar -->
        <?php echo $__env->make('layouts.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- TOP Nav Bar END -->

        <!-- Page Content  -->
        <div id="content-page" class="content-page">
            <div class="container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <!-- Wrapper END -->

    <!-- Footer -->
    <?php echo $__env->make('layouts.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer END -->

    <!-- Optional JavaScript -->
    <?php echo $__env->make('layouts.dashboard._foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1-sib6-arkatama\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>