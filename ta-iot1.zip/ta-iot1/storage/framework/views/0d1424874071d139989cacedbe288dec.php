<?php $__env->startSection('title_menu', 'Led Control'); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        background: linear-gradient(to bottom, #333, #6c757d);
        /* Gradient dari biru ke abu-abu */
        color: #fff;
        /* Warna teks putih */
    }

    .card {
        background-color: #f8f9fa;
        /* Warna latar belakang */
    }

    .card-header {
        background-color: #007bff;
        /* Warna latar belakang header */
        color: #fff;
        /* Warna teks header */
    }

    .card-body {
        background-color: #fff;
        /* Warna latar belakang body */
        color: #000;
        /* Warna teks body */
    }
</style>
<div class="card">
    <h5 class="card-header">LED Control</h5>
    <div class="card-body">
        <h5 class="card-title"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
                <i class="ri-add-line"></i>
                Tambah LED
            </button></h5>
        <p class="card-text">
        <div class="row my-4">
            <?php $__currentLoopData = $leds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $led): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex w-100 justify-content-between">
                            <div class="d-flex align-items-start
                                    <?php if($led->status == '1'): ?> text-primary <?php endif; ?>
                                    ">
                                <i class="ri-lightbulb-line fa-fw fa-4x"></i>
                                <div>
                                    <h6 class="p-0 m-0 fw-bold"><?php echo e($led->name); ?></h6>
                                    <p class="p-0 m-0 text-muted">Pin: <?php echo e($led->pin); ?></p>
                                    <div>
                                        <div class="custom-control custom-switch">
                                            <input <?php if($led->status == '1'): echo 'checked'; endif; ?> type="checkbox"
                                            class="custom-control-input" id="customSwitch<?php echo e($led->id); ?>"
                                            data-pin="<?php echo e($led->pin); ?>">
                                            <label class="custom-control-label" for="customSwitch<?php echo e($led->id); ?>"></label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown">
                                <i class="ri-more-2-fill" type="button" data-toggle="dropdown" aria-expanded="false"></i>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Delete</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </p>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('leds.store')); ?>" method="POST">
            <div class="modal-content">
                <?php echo csrf_field(); ?>

                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Add LED</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">LED Name</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Nama LED">
                    </div>

                    <div class="form-group">
                        <label for="name">LED Pin</label>
                        <input type="number" class="form-control" name="pin" id="pin" placeholder="Pin">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ta-iot1\resources\views/pages/led.blade.php ENDPATH**/ ?>