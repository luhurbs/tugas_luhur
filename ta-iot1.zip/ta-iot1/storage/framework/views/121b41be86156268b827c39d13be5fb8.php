<div class="iq-sidebar">
    <div class="iq-sidebar-logo d-flex justify-content-between">
        <a href="index.html">
            <img src="images/g.png" class="img-fluid" alt="">
            <span style="margin:0cm">GulaBalap</span>
        </a>
        <div class="iq-menu-bt align-self-center">
            <div class="wrapper-menu">
                <div class="line-menu half start"></div>
                <div class="line-menu"></div>
                <div class="line-menu half end"></div>
            </div>
        </div>
    </div>
    <div id="sidebar-scrollbar">
        <nav class="iq-sidebar-menu">
            <ul id="iq-sidebar-toggle" class="iq-menu">
                <li class="
                <?php if(request()->url() == route('dashboard')): ?> active <?php endif; ?>
                ">
                    <a href="<?php echo e(route('dashboard')); ?>" class="iq-waves-effect"><i
                            class="ri-dashboard-fill"></i><span>Dashboard</span></a>
                </li>

                

                <li class="
                <?php if(request()->url() == route('sensor.dht11')): ?> active <?php endif; ?>
                ">
                    <a href="<?php echo e(route('sensor.dht11')); ?>" class="iq-waves-effect"><i
                            class="ri-sensor-fill"></i><span>Sensor</span></a>
                </li>

                <li class="
                <?php if(request()->url() == route('leds.index')): ?> active <?php endif; ?>
                ">
                    <a href="<?php echo e(route('leds.index')); ?>" class="iq-waves-effect"><i
                            class="ri-lightbulb-fill"></i><span>LED Control</span></a>
                </li>

                <li class="
                <?php if(request()->url() == route('users.index')): ?> active <?php endif; ?>
                ">
                        <a href="<?php echo e(route('users.index')); ?>" class="iq-waves-effect"><i
                                class="ri-user-5-fill"></i><span>Pengguna</span></a>
                    </li>

            </ul>
        </nav>
        <div class="p-3"></div>
    </div>
</div>
<?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1-sib6-arkatama\resources\views/layouts/dashboard/sidebar.blade.php ENDPATH**/ ?>