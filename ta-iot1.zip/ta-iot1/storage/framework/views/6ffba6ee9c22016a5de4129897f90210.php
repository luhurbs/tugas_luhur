<?php $__env->startSection('content'); ?>
    <div class="iq-card">
        <div class="iq-card-header d-flex justify-content-between align-items-center">
            <div class="iq-header-title">
                <h4 class="card-title">DHT 11</h4>
            </div>
        </div>
        <div class="iq-card-body">
            <div class="table-responsive">
                <table id="user-list-table" class="table table-striped table-bordered mt-4" role="grid"
                    aria-describedby="user-list-page-info">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Suhu</th>
                            <th>Kelembapan</th>
                            <th>Created_at</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dht11; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($sensor['id']); ?></td>
                                <td><?php echo e($sensor['name']); ?></td>
                                <td><?php echo e($sensor['suhu']); ?></td>
                                <td><?php echo e($sensor['kelembapan']); ?></td>
                                <td><?php echo e($sensor->created_at->format('d M Y, H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="iq-card">
        <div class="iq-card-header d-flex justify-content-between align-items-center">
            <div class="iq-header-title">
                <h4 class="card-title">MQ-5</h4>
            </div>
        </div>
        <div class="iq-card-body">
            <div class="table-responsive">
                <table id="user-list-table" class="table table-striped table-bordered mt-4" role="grid"
                    aria-describedby="user-list-page-info">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Nilai Gas</th>
                            <th>Created_at</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mq5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sensor['id']); ?></td>
                                <td><?php echo e($sensor['name']); ?></td>
                                <td><?php echo e($sensor['nilai_gas']); ?></td>
                                <td><?php echo e($sensor->created_at->format('d M Y, H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="iq-card">
        <div class="iq-card-header d-flex justify-content-between align-items-center">
            <div class="iq-header-title">
                <h4 class="card-title">Rain Sensor</h4>
            </div>
        </div>
        <div class="iq-card-body">
            <div class="table-responsive">
                <table id="user-list-table" class="table table-striped table-bordered mt-4" role="grid"
                    aria-describedby="user-list-page-info">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Nilai Hujan</th>
                            <th>Created_at</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sensor['id']); ?></td>
                                <td><?php echo e($sensor['name']); ?></td>
                                <td><?php echo e($sensor['nilai_rain']); ?></td>
                                <td><?php echo e($sensor->created_at->format('d M Y, H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1-sib6-arkatama\resources\views/pages/sensor.blade.php ENDPATH**/ ?>