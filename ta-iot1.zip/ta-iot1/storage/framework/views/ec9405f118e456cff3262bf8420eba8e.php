<!doctype html>
<html lang="en">

<?php echo $__env->make('layouts.dashboard._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <div id="loading">
         <div id="loading-center">
            <div class="loader">
               <div class="cube">
                  <div class="sides">
                     <div class="top"></div>
                     <div class="right"></div>
                     <div class="bottom"></div>
                     <div class="left"></div>
                     <div class="front"></div>
                     <div class="back"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- loader END -->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Optional JavaScript -->
      <?php echo $__env->make('layouts.dashboard._foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html>
<?php /**PATH C:\ta-iot1\resources\views/layouts/auth.blade.php ENDPATH**/ ?>