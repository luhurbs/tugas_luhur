<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>GulaBalap Internet of Things</title>
<!-- Favicon -->
<link rel="shortcut icon" href="images/g.png" />
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Typography CSS -->
<link rel="stylesheet" href="css/typography.css">
<!-- Style CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1-sib6-arkatama\resources\views/layouts/dashboard/_head.blade.php ENDPATH**/ ?>