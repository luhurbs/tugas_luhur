<footer class="bg-white iq-footer">
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-lg-8 text-right">
                Copyright ©<a href="#">IoT Panel</a> by Stela Juni.
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Project Luhur\Tugas IoT\ta-iot1-sib6-arkatama\resources\views/layouts/dashboard/footer.blade.php ENDPATH**/ ?>